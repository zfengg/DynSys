Material for a talk of how complexity arises from the simplest models.
