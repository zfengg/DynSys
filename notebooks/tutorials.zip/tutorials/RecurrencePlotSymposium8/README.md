The tutorial Jupyter notebook files are contained in the current folder.

Please install Julia version 1.1 or later. You can find it here: https://julialang.org/

Then install the following packages, by pressing `]` to access the package manager and then doing
```
add IJulia DynamicalSystems OrdinaryDiffEq BenchmarkTools Measurements PyPlot Unitful
```

It would be great if you try to run a Jupyter notebook by running the commands:
```julia
using IJulia
notebook()
```
